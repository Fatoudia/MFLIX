package mflix.api.models;

public class MovieTitle extends AbstractMovie {

    public MovieTitle() {
        super();
    }
}
